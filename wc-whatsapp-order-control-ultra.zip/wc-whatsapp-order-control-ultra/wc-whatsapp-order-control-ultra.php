
<?php
/*
Plugin Name: WooCommerce WhatsApp Order Control ULTRA
Description: v8.0 BUSINESS – UI 2025 • WhatsApp Commerce + My Orders + FAQ • Order Command Center • Admin WhatsApp notify on confirm.
Version: 8.0.0
Author: ADC Media
*/
if (!defined('ABSPATH')) exit;

class WCWA_ULTRA_V8 {
  const OPT = 'wcwa_ultra_v8_settings';
  const META_CONFIRMED = '_wcwa_whatsapp_confirmed';
  const META_CONFIRM_MSG = '_wcwa_whatsapp_message';
  const META_CONFIRM_AT = '_wcwa_whatsapp_confirmed_at';

  const META_AWB = '_wcwa_awb_number';
  const META_AWB_PROVIDER = '_wcwa_awb_provider';
  const META_AWB_TRACK = '_wcwa_awb_tracking_url';

  public function __construct(){
    register_activation_hook(__FILE__, [$this,'activate']);

    add_action('init', [$this,'register_statuses']);
    add_action('admin_menu', [$this,'admin_menu']);
    add_action('admin_post_wcwa_ultra_save', [$this,'save_settings']);
    add_action('admin_enqueue_scripts', [$this,'enqueue_admin']);
    add_action('wp_enqueue_scripts', [$this,'enqueue_front']);
    add_action('rest_api_init', [$this,'register_rest']);

    add_action('woocommerce_thankyou', [$this,'render_order_center'], 20);
    add_action('woocommerce_view_order', [$this,'render_order_center'], 20);

    add_filter('manage_edit-shop_order_columns', [$this,'add_order_column'], 20);
    add_action('manage_shop_order_posts_custom_column', [$this,'render_order_column'], 20, 2);
  }

  public function defaults(){
    return [
      'enable_order_center' => 1,
      'enable_confirm_modal' => 1,
      'enable_commerce' => 1,

      'store_wa_number' => '',
      'store_phone' => '',
      'store_email' => '',

      'float_mode' => 'hybrid',
      'float_position' => 'br',
      'float_style' => 'pill',
      'float_label' => 1,
      'float_color' => '#111827',
      'float_dot' => 1,

      'commerce_layout' => 'drawer',
      'commerce_view' => 'carousel',
      'commerce_primary' => 'both',
      'commerce_limit' => 10,

      'show_offers' => 1,
      'show_new' => 1,
      'show_cheap' => 1,
      'show_featured' => 1,

      'src_offers' => 'auto',
      'src_new' => 'auto',
      'src_cheap' => 'auto',
      'src_featured' => 'auto',

      'manual_offers' => '',
      'manual_new' => '',
      'manual_cheap' => '',
      'manual_featured' => '',

      'confirm_status_on_confirm' => 'whatsapp-confirmed',
      'confirm_status_on_sent' => 'whatsapp-pending',
      'confirm_btn_text' => 'Deschide WhatsApp',
      'confirmed_btn_text' => 'Am confirmat',
      'wa_tpl_confirm' =>
        "Salut {nume}, comanda #{id} în valoare de {total} lei este pregătită.\nConfirmă aici 👇\n{link_confirmare}\n\nProduse:\n{products}",

      'wa_tpl_admin_confirmed' =>
        "✅ Confirmare WhatsApp\nComanda #{id}\nClient: {nume}\nTotal: {total} lei\n🕒 {time}\n\nProduse:\n{products}",

      'faq_json' => '',
    ];
  }

  public function get_settings(){
    $opt = get_option(self::OPT, []);
    if (!is_array($opt)) $opt = [];
    $s = array_merge($this->defaults(), $opt);

    if (trim((string)$s['faq_json']) === ''){
      $demo = [
        ['q'=>'Cum confirm comanda?','a'=>'Apasă pe „Am confirmat” după ce ai deschis WhatsApp sau confirmă direct din contul tău.'],
        ['q'=>'În cât timp se livrează?','a'=>'De obicei 24–48h lucrătoare după confirmare.'],
        ['q'=>'Pot modifica adresa sau produsele?','a'=>'Da. Scrie-ne pe WhatsApp și spune ce vrei să modifici.'],
      ];
      $s['faq_json'] = wp_json_encode($demo, JSON_UNESCAPED_UNICODE);
    }
    return $s;
  }

  public function activate(){
    $this->register_statuses();
  }

  public function register_statuses(){
    $statuses = [
      'wc-whatsapp-confirmed' => 'Confirmat WhatsApp',
      'wc-whatsapp-pending'   => 'Așteaptă răspuns WhatsApp',
      'wc-whatsapp-edit'      => 'Client a cerut modificări',
      'wc-whatsapp-cancel'    => 'Anulat prin WhatsApp',
    ];
    foreach($statuses as $key=>$label){
      register_post_status($key, [
        'label' => $label,
        'public' => true,
        'show_in_admin_all_list' => true,
        'show_in_admin_status_list' => true,
      ]);
    }
  }

  public function admin_menu(){
    add_menu_page('WA Order Control','WA Order Control','manage_options','wcwa-ultra',[$this,'page_settings'],'dashicons-whatsapp',56);
  }

  public function enqueue_admin($hook){
    if (strpos($hook,'wcwa-ultra') === false) return;
    wp_enqueue_style('wcwa-ultra-admin', plugins_url('assets/admin.css', __FILE__), [], '8.0.0');
    wp_enqueue_script('wcwa-ultra-admin', plugins_url('assets/admin.js', __FILE__), ['jquery'], '8.0.0', true);
  }

  public function page_settings(){
    if (!current_user_can('manage_options')) return;
    $s = $this->get_settings();
    $nonce = wp_create_nonce('wcwa_ultra_save');
    ?>
    <div class="wcwa-wrap">
      <div class="wcwa-hero">
        <div>
          <h1>WA Order Control <span class="badge">ULTRA v8.0 BUSINESS</span></h1>
          <p>Comenzile mele (logat) • FAQ • Confirmare comandă • Notificare admin pe WhatsApp</p>
        </div>
        <button class="btn ghost" type="button" id="wcwa-admin-preview">Preview overlay</button>
      </div>

      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="wcwa-form">
        <input type="hidden" name="action" value="wcwa_ultra_save">
        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>">

        <div class="wcwa-grid">
          <div class="card">
            <h2>Module</h2>
            <label class="toggle"><input type="checkbox" name="enable_order_center" value="1" <?php checked($s['enable_order_center'],1); ?>><span></span> Order Command Center</label>
            <label class="toggle"><input type="checkbox" name="enable_confirm_modal" value="1" <?php checked($s['enable_confirm_modal'],1); ?>><span></span> Confirmare comandă (buton „Am confirmat”)</label>
            <label class="toggle"><input type="checkbox" name="enable_commerce" value="1" <?php checked($s['enable_commerce'],1); ?>><span></span> WhatsApp Commerce Overlay</label>

            <div class="hr"></div>
            <h3>Contact magazin</h3>
            <div class="field"><label>WhatsApp (număr)</label><input type="text" name="store_wa_number" value="<?php echo esc_attr($s['store_wa_number']); ?>" placeholder="ex: 40747227878"></div>
            <div class="row">
              <div class="field"><label>Telefon (tel:)</label><input type="text" name="store_phone" value="<?php echo esc_attr($s['store_phone']); ?>"></div>
              <div class="field"><label>Email (mailto:)</label><input type="text" name="store_email" value="<?php echo esc_attr($s['store_email']); ?>"></div>
            </div>
            <div class="hint">Numărul WhatsApp este folosit și pentru notificarea ta de admin când clientul confirmă comanda.</div>
          </div>

          <div class="card">
            <h2>Floating Button</h2>
            <div class="row">
              <div class="field">
                <label>Mod click</label>
                <select name="float_mode">
                  <option value="chat" <?php selected($s['float_mode'],'chat'); ?>>Chat direct</option>
                  <option value="overlay" <?php selected($s['float_mode'],'overlay'); ?>>Overlay (produse + cont)</option>
                  <option value="hybrid" <?php selected($s['float_mode'],'hybrid'); ?>>Hybrid (hub)</option>
                </select>
              </div>
              <div class="field">
                <label>Poziție</label>
                <select name="float_position">
                  <option value="br" <?php selected($s['float_position'],'br'); ?>>Dreapta jos</option>
                  <option value="bl" <?php selected($s['float_position'],'bl'); ?>>Stânga jos</option>
                  <option value="tr" <?php selected($s['float_position'],'tr'); ?>>Dreapta sus</option>
                  <option value="tl" <?php selected($s['float_position'],'tl'); ?>>Stânga sus</option>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="field">
                <label>Stil</label>
                <select name="float_style">
                  <option value="pill" <?php selected($s['float_style'],'pill'); ?>>Pill (premium)</option>
                  <option value="round" <?php selected($s['float_style'],'round'); ?>>Round</option>
                  <option value="minimal" <?php selected($s['float_style'],'minimal'); ?>>Minimal</option>
                </select>
              </div>
              <div class="field">
                <label>Culoare</label>
                <input type="text" name="float_color" value="<?php echo esc_attr($s['float_color']); ?>" placeholder="#111827">
              </div>
            </div>
            <label class="toggle"><input type="checkbox" name="float_label" value="1" <?php checked($s['float_label'],1); ?>><span></span> Arată text</label>
            <label class="toggle"><input type="checkbox" name="float_dot" value="1" <?php checked($s['float_dot'],1); ?>><span></span> Dot animat</label>
          </div>

          <div class="card">
            <h2>WhatsApp Commerce</h2>
            <div class="row">
              <div class="field">
                <label>Layout overlay</label>
                <select name="commerce_layout">
                  <option value="drawer" <?php selected($s['commerce_layout'],'drawer'); ?>>Drawer</option>
                  <option value="modal" <?php selected($s['commerce_layout'],'modal'); ?>>Modal</option>
                  <option value="fullscreen" <?php selected($s['commerce_layout'],'fullscreen'); ?>>Fullscreen</option>
                </select>
              </div>
              <div class="field">
                <label>Vizual</label>
                <select name="commerce_view">
                  <option value="carousel" <?php selected($s['commerce_view'],'carousel'); ?>>Carusel</option>
                  <option value="grid" <?php selected($s['commerce_view'],'grid'); ?>>Grid</option>
                </select>
              </div>
            </div>
            <div class="row">
              <div class="field">
                <label>Acțiuni pe produs</label>
                <select name="commerce_primary">
                  <option value="both" <?php selected($s['commerce_primary'],'both'); ?>>Cumpără + WhatsApp</option>
                  <option value="checkout" <?php selected($s['commerce_primary'],'checkout'); ?>>Doar Cumpără</option>
                  <option value="whatsapp" <?php selected($s['commerce_primary'],'whatsapp'); ?>>Doar WhatsApp</option>
                </select>
              </div>
              <div class="field">
                <label>Limită produse / tab</label>
                <input type="number" name="commerce_limit" min="4" max="30" value="<?php echo esc_attr($s['commerce_limit']); ?>">
              </div>
            </div>

            <div class="row">
              <label class="toggle"><input type="checkbox" name="show_offers" value="1" <?php checked($s['show_offers'],1); ?>><span></span> Oferte</label>
              <label class="toggle"><input type="checkbox" name="show_new" value="1" <?php checked($s['show_new'],1); ?>><span></span> Noi</label>
              <label class="toggle"><input type="checkbox" name="show_cheap" value="1" <?php checked($s['show_cheap'],1); ?>><span></span> Ieftine</label>
              <label class="toggle"><input type="checkbox" name="show_featured" value="1" <?php checked($s['show_featured'],1); ?>><span></span> Recomandate</label>
            </div>

            <div class="hr"></div>
            <h3>Aranjare produse (Auto / Manual)</h3>
            <?php $this->tab_source_row('offers','Oferte',$s); ?>
            <?php $this->tab_source_row('new','Noi',$s); ?>
            <?php $this->tab_source_row('cheap','Ieftine',$s); ?>
            <?php $this->tab_source_row('featured','Recomandate',$s); ?>
          </div>

          <div class="card">
            <h2>Template-uri WhatsApp (premium)</h2>
            <div class="row">
              <div class="field">
                <label>Status după „WhatsApp trimis”</label>
                <select name="confirm_status_on_sent"><?php echo $this->status_options($s['confirm_status_on_sent']); ?></select>
              </div>
              <div class="field">
                <label>Status după „Am confirmat”</label>
                <select name="confirm_status_on_confirm"><?php echo $this->status_options($s['confirm_status_on_confirm']); ?></select>
              </div>
            </div>
            <div class="row">
              <div class="field"><label>Text buton WhatsApp</label><input type="text" name="confirm_btn_text" value="<?php echo esc_attr($s['confirm_btn_text']); ?>"></div>
              <div class="field"><label>Text buton confirmare</label><input type="text" name="confirmed_btn_text" value="<?php echo esc_attr($s['confirmed_btn_text']); ?>"></div>
            </div>

            <label><strong>Mesaj către client (confirmare)</strong></label>
            <textarea name="wa_tpl_confirm" rows="7"><?php echo esc_textarea($s['wa_tpl_confirm']); ?></textarea>
            <div class="hint">Variabile: {nume} {id} {total} {products} {link_confirmare}</div>

            <label style="margin-top:10px"><strong>Mesaj către ADMIN (când clientul confirmă)</strong></label>
            <textarea name="wa_tpl_admin_confirmed" rows="7"><?php echo esc_textarea($s['wa_tpl_admin_confirmed']); ?></textarea>
            <div class="hint">Variabile: {nume} {id} {total} {products} {time}</div>
          </div>

          <div class="card">
            <h2>FAQ (Overlay)</h2>
            <div class="hint">Editează FAQ-ul (JSON). Dacă lași gol, se folosește DEMO.</div>
            <textarea name="faq_json" rows="10"><?php echo esc_textarea($s['faq_json']); ?></textarea>
            <div class="hint">Format: [{"q":"Întrebare","a":"Răspuns"}]</div>
          </div>

        </div>

        <div class="actions">
          <button class="btn primary" type="submit">Salvează</button>
        </div>
      </form>
    </div>
    <?php
  }

  private function tab_source_row($key, $label, $s){
    $src = $s['src_'.$key] ?? 'auto';
    $manual = $s['manual_'.$key] ?? '';
    echo '<div class="tabrow">
      <div class="tabhead">'.$label.'</div>
      <div class="row">
        <div class="field">
          <label>Sursă</label>
          <select name="src_'.$key.'">
            <option value="auto" '.selected($src,'auto',false).'>Auto</option>
            <option value="manual" '.selected($src,'manual',false).'>Manual (ID-uri)</option>
          </select>
        </div>
        <div class="field">
          <label>ID-uri produse (manual)</label>
          <input type="text" name="manual_'.$key.'" value="'.esc_attr($manual).'" placeholder="ex: 12,44,105">
        </div>
      </div>
    </div>';
  }

  private function status_options($selected){
    $map = [
      'pending' => 'În așteptare plată',
      'processing' => 'În procesare',
      'on-hold' => 'În așteptare',
      'completed' => 'Finalizată',
      'cancelled' => 'Anulată',
      'refunded' => 'Rambursată',
      'failed' => 'Eșuată',
      'whatsapp-pending' => 'Așteaptă răspuns WhatsApp',
      'whatsapp-confirmed' => 'Confirmat WhatsApp',
      'whatsapp-edit' => 'Client a cerut modificări',
      'whatsapp-cancel' => 'Anulat prin WhatsApp',
    ];
    $out = '';
    foreach($map as $k=>$label){
      $out .= '<option value="'.esc_attr($k).'" '.selected($selected,$k,false).'>'.esc_html($label).'</option>';
    }
    return $out;
  }

  public function save_settings(){
    if (!current_user_can('manage_options')) wp_die('No access');
    check_admin_referer('wcwa_ultra_save');

    $s = $this->get_settings();

    $checks = [
      'enable_order_center','enable_confirm_modal','enable_commerce',
      'float_label','float_dot',
      'show_offers','show_new','show_cheap','show_featured',
    ];
    foreach($checks as $c){ $s[$c] = isset($_POST[$c]) ? 1 : 0; }

    $fields = [
      'store_wa_number','store_phone','store_email',
      'float_mode','float_position','float_style','float_color',
      'commerce_layout','commerce_view','commerce_primary','commerce_limit',
      'src_offers','src_new','src_cheap','src_featured',
      'manual_offers','manual_new','manual_cheap','manual_featured',
      'confirm_status_on_confirm','confirm_status_on_sent','confirm_btn_text','confirmed_btn_text',
      'wa_tpl_confirm','wa_tpl_admin_confirmed',
      'faq_json'
    ];
    foreach($fields as $f){
      if (isset($_POST[$f])) $s[$f] = is_string($_POST[$f]) ? wp_unslash($_POST[$f]) : $_POST[$f];
    }

    $s['store_wa_number'] = preg_replace('/\D+/', '', (string)$s['store_wa_number']);
    $s['store_phone'] = preg_replace('/\D+/', '', (string)$s['store_phone']);
    $s['store_email'] = sanitize_email((string)$s['store_email']);
    $s['commerce_limit'] = max(4, min(30, intval($s['commerce_limit'])));

    $faq = trim((string)$s['faq_json']);
    if ($faq !== ''){
      $decoded = json_decode($faq, true);
      if (!is_array($decoded)) $s['faq_json'] = '';
    }

    update_option(self::OPT, $s, false);
    wp_redirect(admin_url('admin.php?page=wcwa-ultra&saved=1'));
    exit;
  }

  public function enqueue_front(){
    if (!class_exists('WooCommerce')) return;
    $s = $this->get_settings();

    wp_enqueue_style('wcwa-ultra-front', plugins_url('assets/frontend.css', __FILE__), [], '8.0.0');
    wp_enqueue_script('wcwa-ultra-front', plugins_url('assets/frontend.js', __FILE__), ['jquery'], '8.0.0', true);

    wp_localize_script('wcwa-ultra-front', 'WCWA_ULTRA', [
      'rest' => esc_url_raw(rest_url('wcwa/v1')),
      'nonce' => wp_create_nonce('wp_rest'),
      'layout' => (string)$s['commerce_layout'],
      'view' => (string)$s['commerce_view'],
      'primary' => (string)$s['commerce_primary'],
      'limit' => intval($s['commerce_limit']),
      'show' => [
        'offers' => (int)$s['show_offers'],
        'new' => (int)$s['show_new'],
        'cheap' => (int)$s['show_cheap'],
        'featured' => (int)$s['show_featured'],
      ],
      'src' => [
        'offers' => (string)$s['src_offers'],
        'new' => (string)$s['src_new'],
        'cheap' => (string)$s['src_cheap'],
        'featured' => (string)$s['src_featured'],
      ],
      'storeWa' => (string)$s['store_wa_number'],
      'storePhone' => (string)$s['store_phone'],
      'storeEmail' => (string)$s['store_email'],
      'float' => [
        'mode' => (string)$s['float_mode'],
        'pos' => (string)$s['float_position'],
        'style' => (string)$s['float_style'],
        'label' => (int)$s['float_label'],
        'color' => (string)$s['float_color'],
        'dot' => (int)$s['float_dot'],
      ],
      'faq' => $this->safe_faq_array($s),
      'checkoutUrl' => function_exists('wc_get_checkout_url') ? wc_get_checkout_url() : site_url('/checkout/'),
      'cartUrl' => function_exists('wc_get_cart_url') ? wc_get_cart_url() : site_url('/cart/'),
    ]);
  }

  private function safe_faq_array($s){
    $faq = json_decode((string)$s['faq_json'], true);
    if (!is_array($faq)) return [];
    $out = [];
    foreach($faq as $it){
      $q = isset($it['q']) ? wp_strip_all_tags((string)$it['q']) : '';
      $a = isset($it['a']) ? wp_kses_post((string)$it['a']) : '';
      if ($q && $a) $out[] = ['q'=>$q,'a'=>$a];
    }
    return $out;
  }

  public function register_rest(){
    register_rest_route('wcwa/v1', '/products', [
      'methods' => 'GET',
      'permission_callback' => '__return_true',
      'callback' => [$this,'rest_products'],
      'args' => ['tab' => ['required'=>true]]
    ]);

    register_rest_route('wcwa/v1', '/confirm', [
      'methods' => 'POST',
      'permission_callback' => '__return_true',
      'callback' => [$this,'rest_confirm'],
    ]);

    register_rest_route('wcwa/v1', '/my-orders', [
      'methods' => 'GET',
      'permission_callback' => function(){ return is_user_logged_in(); },
      'callback' => [$this,'rest_my_orders'],
    ]);
  }

  public function rest_products($req){
    if (!class_exists('WooCommerce')) return new WP_REST_Response(['error'=>'WooCommerce missing'], 400);
    $s = $this->get_settings();
    if (!$s['enable_commerce']) return new WP_REST_Response(['error'=>'Commerce disabled'], 403);

    $tab = sanitize_text_field($req->get_param('tab'));
    $limit = max(4, min(30, intval($req->get_param('limit')) ?: intval($s['commerce_limit'])));

    $source = $s['src_'.$tab] ?? 'auto';
    $manual = $s['manual_'.$tab] ?? '';

    $args = ['limit'=>$limit, 'status'=>'publish', 'return'=>'objects'];
    $use_manual = false;

    if ($source === 'manual' && trim($manual) !== ''){
      $ids = array_filter(array_map('intval', preg_split('/\s*,\s*/', $manual)));
      if (!empty($ids)) {
        $args['include'] = $ids;
        $args['orderby'] = 'post__in';
        $use_manual = true;
      }
    }

    if (!$use_manual) {
      if ($tab === 'offers'){
        $args['on_sale'] = true; $args['orderby'] = 'date'; $args['order'] = 'DESC';
      } elseif ($tab === 'new'){
        $args['orderby'] = 'date'; $args['order'] = 'DESC';
      } elseif ($tab === 'cheap'){
        $args['orderby'] = 'price'; $args['order'] = 'ASC';
      } elseif ($tab === 'featured'){
        $args['featured'] = true; $args['orderby'] = 'date'; $args['order'] = 'DESC';
      } else {
        return new WP_REST_Response(['error'=>'Invalid tab'], 400);
      }
    }

    $products = wc_get_products($args);
    $out = [];
    foreach($products as $p){
      $img_id = $p->get_image_id();
      $img = $img_id ? wp_get_attachment_image_url($img_id, 'medium') : wc_placeholder_img_src('medium');
      $out[] = [
        'id' => $p->get_id(),
        'name' => $p->get_name(),
        'price_html' => $p->get_price_html(),
        'permalink' => $p->get_permalink(),
        'image' => $img,
        'add_to_cart' => add_query_arg(['add-to-cart'=>$p->get_id()], wc_get_cart_url()),
      ];
    }
    return new WP_REST_Response(['items'=>$out], 200);
  }

  public function rest_my_orders($req){
    $user_id = get_current_user_id();
    if (!$user_id) return new WP_REST_Response(['error'=>'not_logged_in'], 403);

    $orders = wc_get_orders([
      'customer_id' => $user_id,
      'limit' => 10,
      'orderby' => 'date',
      'order' => 'DESC',
      'return' => 'objects',
    ]);

    $out = [];
    foreach($orders as $o){
      $items = [];
      foreach($o->get_items() as $it){
        $items[] = $it->get_name().' x'.$it->get_quantity();
      }
      $confirmed = (int)get_post_meta($o->get_id(), self::META_CONFIRMED, true);
      $confirmed_at = (int)get_post_meta($o->get_id(), self::META_CONFIRM_AT, true);
      $awb = (string)get_post_meta($o->get_id(), self::META_AWB, true);
      $track = (string)get_post_meta($o->get_id(), self::META_AWB_TRACK, true);

      $out[] = [
        'id' => $o->get_id(),
        'date' => $o->get_date_created() ? $o->get_date_created()->date_i18n('d.m.Y H:i') : '',
        'total' => wc_price($o->get_total()),
        'status' => $o->get_status(),
        'status_label' => wc_get_order_status_name($o->get_status()),
        'items' => $items,
        'confirmed' => $confirmed,
        'confirmed_at' => $confirmed_at ? date_i18n('d.m.Y H:i', $confirmed_at) : '',
        'awb' => $awb,
        'track' => $track,
        'view' => $o->get_view_order_url(),
      ];
    }

    return new WP_REST_Response(['items'=>$out], 200);
  }

  public function rest_confirm($req){
    $params = $req->get_json_params();
    $order_id = isset($params['order_id']) ? intval($params['order_id']) : 0;
    $token = isset($params['token']) ? sanitize_text_field($params['token']) : '';
    $note = isset($params['note']) ? wp_strip_all_tags((string)$params['note']) : '';

    if (!$order_id || !$token) return new WP_REST_Response(['ok'=>false,'error'=>'missing'], 400);
    $order = wc_get_order($order_id);
    if (!$order) return new WP_REST_Response(['ok'=>false,'error'=>'no_order'], 404);
    if (!$this->verify_token($order_id, $token)) return new WP_REST_Response(['ok'=>false,'error'=>'bad_token'], 403);

    $s = $this->get_settings();
    $order->update_status($s['confirm_status_on_confirm'], 'Confirmat de client prin WhatsApp.');
    update_post_meta($order_id, self::META_CONFIRMED, 1);
    update_post_meta($order_id, self::META_CONFIRM_AT, time());
    if ($note !== '') update_post_meta($order_id, self::META_CONFIRM_MSG, $note);

    $wa_url = $this->notify_admin_whatsapp($order, $s);

    return new WP_REST_Response(['ok'=>true, 'wa_url'=>$wa_url], 200);
  }

  private function notify_admin_whatsapp($order, $s){
    $wa = preg_replace('/\D+/', '', (string)$s['store_wa_number']);
    if (!$wa) return '';

    $items = [];
    foreach($order->get_items() as $it){
      $items[] = $it->get_name().' x'.$it->get_quantity();
    }
    $products_txt = implode("\n", $items);

    $msg = (string)$s['wa_tpl_admin_confirmed'];
    $msg = str_replace(
      ['{nume}','{id}','{total}','{products}','{time}'],
      [$order->get_formatted_billing_full_name(), $order->get_id(), wc_format_decimal($order->get_total(), 2), $products_txt, date_i18n('H:i')],
      $msg
    );

    $url = 'https://wa.me/'.$wa.'?text='.rawurlencode($msg);
    $order->add_order_note('📲 Admin WhatsApp (deschide link): '.$url);
    return $url;
  }

  public function render_order_center($order_id){
    $s = $this->get_settings();
    if (!$s['enable_order_center']) return;
    if(!$order_id) return;
    $order = wc_get_order($order_id);
    if(!$order) return;

    $token = $this->make_token($order_id);
    $confirm_link = add_query_arg(['wcwa_confirm'=>1,'order_id'=>$order_id,'token'=>$token], home_url('/'));

    $products = [];
    foreach($order->get_items() as $item){
      $products[] = $item->get_name().' x'.$item->get_quantity();
    }
    $products_txt = implode("\n", $products);

    $msg = (string)$s['wa_tpl_admin_confirmed'];
    $msg = str_replace(
      ['{nume}','{id}','{total}','{products}','{time}'],
      [$order->get_formatted_billing_full_name(), $order->get_id(), wc_format_decimal($order->get_total(), 2), $products_txt, date_i18n('H:i')],
      $msg
    );

    $wa = preg_replace('/\D+/', '', (string)$s['store_wa_number']);
    $wa_url = $wa ? 'https://wa.me/'.$wa.'?text='.rawurlencode($msg) : '';

    $confirmed = (int) get_post_meta($order_id, self::META_CONFIRMED, true);
    $note = (string) get_post_meta($order_id, self::META_CONFIRM_MSG, true);
    $confirmed_at = (int) get_post_meta($order_id, self::META_CONFIRM_AT, true);

    $awb = get_post_meta($order_id, self::META_AWB, true);
    $track = get_post_meta($order_id, self::META_AWB_TRACK, true);

    echo '<div class="wcwa-occ" data-order="'.esc_attr($order_id).'" data-token="'.esc_attr($token).'" data-wa="'.esc_attr($wa_url).'">
      <div class="occ-top">
        <div class="occ-title">🧭 Order Command Center</div>
        <div class="occ-sub">Comanda #'.esc_html($order->get_id()).' • '.esc_html(wc_get_order_status_name($order->get_status())).'</div>
      </div>

      <div class="occ-steps">
        <div class="step done">🧾 Plasată</div>
        <div class="step '.($confirmed?'done':'wait').'">✅ Confirmare</div>
        <div class="step '.($awb?'done':'wait').'">📦 AWB</div>
        <div class="step '.($order->has_status('completed')?'done':'wait').'">🎉 Livrată</div>
      </div>

      <div class="occ-actions">
        '.($wa_url ? '<a class="btn primary" target="_blank" rel="noopener" href="'.esc_url($wa_url).'">'.esc_html($s['confirm_btn_text']).'</a>' : '<div class="muted">Setează numărul WhatsApp în plugin.</div>').'
        <button type="button" class="btn confirm" '.($confirmed?'disabled':'').'>'.esc_html($s['confirmed_btn_text']).'</button>
        '.($track ? '<a class="btn" target="_blank" rel="noopener" href="'.esc_url($track).'">🔎 Tracking</a>' : '').'
      </div>

      <div class="occ-meta">
        <div class="chip">✅ Confirmare: <strong>'.($confirmed ? 'DA' : 'NU').'</strong></div>
        '.($confirmed_at ? '<div class="chip">🕒 '.esc_html(date_i18n('d.m.Y H:i', $confirmed_at)).'</div>' : '').'
        '.($awb ? '<div class="chip">📦 AWB: <strong>'.esc_html($awb).'</strong></div>' : '<div class="chip">📦 AWB: —</div>').'
      </div>

      '.($note ? '<div class="occ-note"><strong>Note client:</strong> '.esc_html($note).'</div>' : '').'
    </div>';
  }

  private function make_token($order_id){
    $secret = defined('AUTH_KEY') ? AUTH_KEY : wp_salt('auth');
    return substr(hash_hmac('sha256', 'wcwa|'.$order_id, $secret), 0, 24);
  }
  private function verify_token($order_id, $token){
    return hash_equals($this->make_token($order_id), $token);
  }

  public function add_order_column($cols){
    $cols['wcwa_whatsapp'] = 'WhatsApp';
    return $cols;
  }

  public function render_order_column($col, $post_id){
    if ($col !== 'wcwa_whatsapp') return;

    $order = wc_get_order($post_id);
    if (!$order){ echo '—'; return; }

    $confirmed = (int)get_post_meta($post_id, self::META_CONFIRMED, true);
    $note = (string)get_post_meta($post_id, self::META_CONFIRM_MSG, true);
    $at = (int)get_post_meta($post_id, self::META_CONFIRM_AT, true);

    $items = [];
    foreach($order->get_items() as $it){
      $items[] = $it->get_name().' x'.$it->get_quantity();
    }
    $short = implode(', ', array_slice($items, 0, 2));
    if (count($items) > 2) $short .= '…';

    echo $confirmed ? '<span class="wcwa-pill ok">Confirmată</span>' : '<span class="wcwa-pill">Neconfirmată</span>';
    echo '<div class="wcwa-mini"><strong>Produse:</strong> '.esc_html($short).'</div>';
    if ($at) echo '<div class="wcwa-mini"><strong>Ora:</strong> '.esc_html(date_i18n('d.m H:i', $at)).'</div>';
    if ($note) echo '<div class="wcwa-mini"><strong>Notă:</strong> '.esc_html($note).'</div>';

    $phone = preg_replace('/\D+/', '', (string)$order->get_billing_phone());
    if ($phone){
      $msg = "Salut ".$order->get_formatted_billing_full_name().",\nRevenim cu update pentru comanda #".$order->get_id().".\nStatus: ".wc_get_order_status_name($order->get_status())."\n";
      $url = 'https://wa.me/'.$phone.'?text='.rawurlencode($msg);
      echo '<div style="margin-top:6px"><a class="button button-small" target="_blank" rel="noopener" href="'.esc_url($url).'">🔔 Notifică clientul</a></div>';
    }
  }
}

new WCWA_ULTRA_V8();
