
(function($){
  function waLink(phone, text){
    const p = String(phone||'').replace(/\D+/g,'');
    if(!p) return '';
    return 'https://wa.me/' + p + '?text=' + encodeURIComponent(text||'');
  }

  function mountFloating(){
    if(!window.WCWA_ULTRA) return;
    const f = WCWA_ULTRA.float || {};
    if($('.wcwa-float').length) return;

    const pos = f.pos || 'br';
    const style = f.style || 'pill';
    const label = !!f.label;
    const dot = !!f.dot;
    const color = f.color || '#111827';

    const cls = `wcwa-float pos-${pos} style-${style}`;
    $('body').append(`
      <button class="${cls}" type="button" aria-label="WhatsApp" style="--wcwaFloat:${color}">
        ${dot ? '<span class="dot"></span>' : ''}
        <span class="icon">💬</span>
        ${label ? '<span class="label">WhatsApp</span>' : ''}
      </button>
    `);

    $('.wcwa-float').on('click', function(){
      const mode = (f.mode || 'hybrid');
      if(mode === 'chat') openChat(true);
      else if(mode === 'overlay') openOverlay();
      else openHub();
    });
  }

  function ensureOverlay(){
    if($('#wcwa-overlay').length) return;
    const layout = WCWA_ULTRA.layout || 'drawer';
    $('body').append(`
      <div id="wcwa-overlay" class="wcwa-overlay ${layout}" aria-hidden="true">
        <div class="wcwa-backdrop"></div>
        <div class="wcwa-panel" role="dialog" aria-modal="true">
          <div class="wcwa-top">
            <div class="wcwa-title">💬 Cont & Produse</div>
            <button class="wcwa-close" type="button" aria-label="Închide">✕</button>
          </div>

          <div class="wcwa-hub" style="display:none">
            <button class="hub-btn" data-act="products">🛍️ Vezi produse</button>
            <button class="hub-btn" data-act="chat">💬 Întrebări (WhatsApp)</button>
            <button class="hub-btn" data-act="orders">📦 Comenzile mele</button>
            <button class="hub-btn" data-act="faq">❓ Întrebări (FAQ)</button>
          </div>

          <div class="wcwa-tabs"></div>
          <div class="wcwa-body">
            <div class="wcwa-loading">Se încarcă…</div>
            <div class="wcwa-wrapview"></div>
          </div>

          <div class="wcwa-footer">
            <a class="foot-btn" href="#" data-act="chat">WhatsApp</a>
            <a class="foot-btn" href="#" data-act="email">Email</a>
            <a class="foot-btn" href="#" data-act="call">Call</a>
          </div>
        </div>
      </div>
    `);

    $('#wcwa-overlay .wcwa-backdrop, #wcwa-overlay .wcwa-close').on('click', closeOverlay);

    $('#wcwa-overlay').on('click', '.hub-btn, .foot-btn', function(e){
      e.preventDefault();
      const act = $(this).data('act');
      if(act === 'products') showProductsUI();
      if(act === 'orders') showMyOrders();
      if(act === 'faq') showFAQ();
      if(act === 'chat') openChat(false);
      if(act === 'call') openCall();
      if(act === 'email') openEmail();
    });
  }

  function openOverlay(){
    ensureOverlay();
    $('#wcwa-overlay').addClass('open').attr('aria-hidden','false');
    showProductsUI();
  }
  function openHub(){
    ensureOverlay();
    $('#wcwa-overlay').addClass('open').attr('aria-hidden','false');
    $('#wcwa-overlay .wcwa-hub').show();
    $('#wcwa-overlay .wcwa-tabs').hide();
    $('#wcwa-overlay .wcwa-body').hide();
  }
  function closeOverlay(){
    $('#wcwa-overlay').removeClass('open').attr('aria-hidden','true');
  }

  function openChat(closeAfter){
    const phone = WCWA_ULTRA.storeWa;
    const url = waLink(phone, 'Salut! Am o întrebare.');
    if(url) window.open(url, '_blank', 'noopener');
    if(closeAfter) closeOverlay();
  }
  function openCall(){
    const p = (WCWA_ULTRA.storePhone||'').replace(/\D+/g,'');
    if(p) window.location.href = 'tel:' + p;
  }
  function openEmail(){
    const e = WCWA_ULTRA.storeEmail||'';
    if(e) window.location.href = 'mailto:' + e;
  }

  function tabsList(){
    const show = WCWA_ULTRA.show || {};
    const tabs = [];
    if(show.offers) tabs.push({id:'offers', label:'🔥 Oferte'});
    if(show.new) tabs.push({id:'new', label:'🆕 Noi'});
    if(show.cheap) tabs.push({id:'cheap', label:'💸 Ieftine'});
    if(show.featured) tabs.push({id:'featured', label:'⭐ Recomandate'});
    return tabs.length ? tabs : [{id:'new', label:'🆕 Noi'}];
  }

  function showProductsUI(){
    $('#wcwa-overlay .wcwa-hub').hide();
    $('#wcwa-overlay .wcwa-tabs').show();
    $('#wcwa-overlay .wcwa-body').show();
    const tabs = tabsList();
    renderTabs(tabs);
    loadTab(tabs[0].id);
  }

  function renderTabs(tabs){
    const $tabs = $('#wcwa-overlay .wcwa-tabs').empty();
    tabs.forEach((t,i)=>{
      const $b = $(`<button type="button" class="wcwa-tab ${i===0?'active':''}" data-tab="${t.id}">${t.label}</button>`);
      $b.on('click', function(){
        $('.wcwa-tab').removeClass('active');
        $(this).addClass('active');
        loadTab(t.id);
      });
      $tabs.append($b);
    });
  }

  function renderView(items){
    const view = WCWA_ULTRA.view || 'carousel';
    const $wrap = $('#wcwa-overlay .wcwa-wrapview').empty();

    if(view === 'grid'){
      const $grid = $('<div class="wcwa-grid"></div>');
      items.forEach(p=> $grid.append(renderCard(p)));
      $wrap.append($grid);
      return;
    }

    const $car = $(`
      <div class="wcwa-carousel">
        <button class="nav prev" type="button" aria-label="Prev">‹</button>
        <div class="track"></div>
        <button class="nav next" type="button" aria-label="Next">›</button>
      </div>
    `);
    const $track = $car.find('.track');
    items.forEach(p=> $track.append(renderCard(p, true)));

    $car.find('.prev').on('click', ()=> $track[0].scrollBy({left:-260, behavior:'smooth'}));
    $car.find('.next').on('click', ()=> $track[0].scrollBy({left:260, behavior:'smooth'}));
    $wrap.append($car);
  }

  function renderCard(p, carousel){
    const primary = WCWA_ULTRA.primary || 'both';
    const checkoutUrl = WCWA_ULTRA.checkoutUrl || '/checkout/';
    const addToCart = p.add_to_cart || (WCWA_ULTRA.cartUrl + '?add-to-cart=' + p.id);

    const $c = $(`
      <div class="wcwa-card ${carousel?'is-carousel':''}">
        <div class="img"><img alt="" loading="lazy"></div>
        <div class="name"></div>
        <div class="price"></div>
        <div class="actions"></div>
      </div>
    `);
    $c.find('img').attr('src', p.image || '');
    $c.find('.name').text(p.name || '');
    $c.find('.price').html(p.price_html || '');

    const $a = $c.find('.actions');
    const $buy = $(`<a class="btn primary" href="${addToCart}">Cumpără</a>`).on('click', function(){
      setTimeout(()=>{ window.location.href = checkoutUrl; }, 650);
    });

    const phone = WCWA_ULTRA.storeWa || '';
    const msg = `Salut! Sunt interesat de produsul:\n${p.name}\n${p.permalink}`;
    const $talk = $(`<a class="btn" target="_blank" rel="noopener" href="${waLink(phone, msg)}">WhatsApp</a>`);

    if(primary === 'checkout') $a.append($buy);
    else if(primary === 'whatsapp') $a.append($talk);
    else $a.append($buy).append($talk);

    return $c;
  }

  function loadTab(tab){
    $('#wcwa-overlay .wcwa-loading').text('Se încarcă…').show();
    $('#wcwa-overlay .wcwa-wrapview').empty();
    const url = `${WCWA_ULTRA.rest}/products?tab=${encodeURIComponent(tab)}&limit=${encodeURIComponent(WCWA_ULTRA.limit||10)}`;
    fetch(url).then(r=>r.json()).then(data=>{
      $('#wcwa-overlay .wcwa-loading').hide();
      const items = (data && data.items) ? data.items : [];
      if(!items.length){
        $('#wcwa-overlay .wcwa-wrapview').html('<div class="wcwa-empty">Nu există produse pentru acest tab.</div>');
        return;
      }
      renderView(items);
    }).catch(()=>{
      $('#wcwa-overlay .wcwa-loading').hide();
      $('#wcwa-overlay .wcwa-wrapview').html('<div class="wcwa-empty">Eroare la încărcare. Verifică REST API / cache / securitate.</div>');
    });
  }

  function showFAQ(){
    $('#wcwa-overlay .wcwa-hub').hide();
    $('#wcwa-overlay .wcwa-tabs').hide();
    $('#wcwa-overlay .wcwa-body').show();
    $('#wcwa-overlay .wcwa-loading').hide();

    const faq = WCWA_ULTRA.faq || [];
    if(!faq.length){
      $('#wcwa-overlay .wcwa-wrapview').html('<div class="wcwa-empty">FAQ indisponibil.</div>');
      return;
    }
    const $box = $('<div class="wcwa-faq"></div>');
    faq.forEach(it=>{
      const $i = $(`
        <div class="faq-item">
          <button type="button" class="faq-q">${it.q}</button>
          <div class="faq-a" style="display:none">${it.a}</div>
        </div>
      `);
      $i.find('.faq-q').on('click', function(){
        const $a = $i.find('.faq-a');
        $a.toggle();
      });
      $box.append($i);
    });
    $('#wcwa-overlay .wcwa-wrapview').empty().append($box);
  }

  function showMyOrders(){
    $('#wcwa-overlay .wcwa-hub').hide();
    $('#wcwa-overlay .wcwa-tabs').hide();
    $('#wcwa-overlay .wcwa-body').show();
    $('#wcwa-overlay .wcwa-loading').text('Se încarcă comenzile…').show();
    $('#wcwa-overlay .wcwa-wrapview').empty();

    fetch(`${WCWA_ULTRA.rest}/my-orders`, { headers: {'X-WP-Nonce': WCWA_ULTRA.nonce} })
      .then(r=>r.json()).then(data=>{
        $('#wcwa-overlay .wcwa-loading').hide();
        if(data && (data.code === 'rest_forbidden' || data.error === 'not_logged_in')){
          $('#wcwa-overlay .wcwa-wrapview').html('<div class="wcwa-empty">Trebuie să fii logat ca să vezi comenzile.</div>');
          return;
        }
        const items = (data && data.items) ? data.items : [];
        if(!items.length){
          $('#wcwa-overlay .wcwa-wrapview').html('<div class="wcwa-empty">Nu ai comenzi încă.</div>');
          return;
        }
        const $list = $('<div class="wcwa-orders"></div>');
        items.forEach(o=>{
          const badge = o.confirmed ? '<span class="b ok">Confirmată</span>' : '<span class="b">Neconfirmată</span>';
          const awb = o.awb ? `<div class="m">📦 AWB: <strong>${o.awb}</strong></div>` : '';
          const track = o.track ? `<a class="btn sm" target="_blank" rel="noopener" href="${o.track}">Tracking</a>` : '';
          const itemsTxt = (o.items || []).slice(0,3).join(', ') + ((o.items||[]).length>3?'…':'');

          const $card = $(`
            <div class="order-card">
              <div class="top">
                <div class="id">Comanda #${o.id}</div>
                ${badge}
              </div>
              <div class="m">🕒 ${o.date}</div>
              <div class="m">Status: <strong>${o.status_label}</strong></div>
              <div class="m">Produse: ${itemsTxt}</div>
              ${o.confirmed_at ? `<div class="m">✅ Confirmată la: <strong>${o.confirmed_at}</strong></div>` : ''}
              ${awb}
              <div class="actions">
                <a class="btn sm" href="${o.view}">Vezi</a>
                ${track}
              </div>
            </div>
          `);
          $list.append($card);
        });
        $('#wcwa-overlay .wcwa-wrapview').empty().append($list);
      }).catch(()=>{
        $('#wcwa-overlay .wcwa-loading').hide();
        $('#wcwa-overlay .wcwa-wrapview').html('<div class="wcwa-empty">Eroare la încărcare comenzi.</div>');
      });
  }

  function bindOCC(){
    $(document).on('click', '.wcwa-occ .btn.confirm', function(){
      const $occ = $(this).closest('.wcwa-occ');
      const orderId = $occ.data('order');
      const token = $occ.data('token');
      const waUrl = $occ.data('wa');
      const btn = this;

      const note = window.prompt('Notă pentru magazin (opțional):', '') || '';

      fetch(WCWA_ULTRA.rest + '/confirm', {
        method:'POST',
        headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': WCWA_ULTRA.nonce },
        body: JSON.stringify({order_id: orderId, token: token, note: note})
      }).then(()=>{
        $(btn).prop('disabled', true).text('Confirmat ✓');
        $occ.find('.occ-steps .step').eq(1).removeClass('wait').addClass('done');
        if(waUrl) window.open(waUrl, '_blank', 'noopener');
      }).catch(()=>{
        if(waUrl) window.open(waUrl, '_blank', 'noopener');
      });
    });
  }

  function handleUrlConfirm(oid, token){
    const $m = $(`
      <div style="position:fixed;top:0;left:0;right:0;bottom:0;z-index:999999;background:rgba(0,0,0,0.85);display:flex;align-items:center;justify-content:center;color:#fff;flex-direction:column;gap:20px;font-family:sans-serif;text-align:center;padding:20px;">
        <div style="font-size:3em;">⏳</div>
        <div style="font-size:1.2em;">Se confirmă comanda #${oid}…</div>
      </div>
    `).appendTo('body');

    fetch(WCWA_ULTRA.rest + '/confirm', {
       method:'POST',
       headers:{ 'Content-Type':'application/json', 'X-WP-Nonce': WCWA_ULTRA.nonce },
       body: JSON.stringify({order_id: oid, token: token})
     }).then(r=>r.json()).then(d=>{
        if(d.ok){
          $m.html('<div style="font-size:4em;">✅</div><div style="font-size:1.5em;font-weight:bold">Comandă confirmată!</div><div>Mulțumim.</div>');
          setTimeout(()=> $m.fadeOut(()=>$m.remove()), 2500);
          if(d.wa_url) window.open(d.wa_url, '_blank', 'noopener');
        } else {
          $m.html('<div style="font-size:4em;">⚠️</div><div style="font-size:1.2em;">Eroare: '+ (d.error||'Unknown') +'</div>');
          setTimeout(()=> $m.fadeOut(()=>$m.remove()), 3000);
        }
     }).catch(()=>{
        $m.html('<div>Eroare conexiune.</div>');
        setTimeout(()=> $m.fadeOut(()=>$m.remove()), 3000);
     });
  }

  function checkUrlActions(){
    if(!window.URLSearchParams) return;
    const q = new URLSearchParams(window.location.search);

    // Preview
    if(q.has('wcwa_preview')){
      setTimeout(openOverlay, 500);
    }

    // Confirm
    if(q.get('wcwa_confirm') === '1' && q.get('order_id') && q.get('token')){
      handleUrlConfirm(q.get('order_id'), q.get('token'));
    }
  }

  $(function(){
    mountFloating();
    ensureOverlay();
    bindOCC();
    checkUrlActions();
  });
})(jQuery);
